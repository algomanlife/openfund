# Openfund: production notes

Status: strategic and visual proposal, pending approval. Both editions share the same structure and supplied logo assets. Product categories and examples are illustrative, not evidence of live services.

## Asset inventory

- `assets/logos/Openfund-mark-{green,white,black,original-magenta}.svg`: supplied approved mark variants; original geometry preserved. ViewBox 581 × 644. The original magenta variant is not evidence of an approved master palette.
- `assets/logos/Openfund-mark-*-4096.png`: supplied raster variants; 4096 × 4096 pixels. Use SVG for scalable reproduction.
- Earlier source: `../Openfund_Brandbook.html` (13-page concept; contains legacy runtime replacement). `Openfund_Brandbook(1).html` was not found in workspace or supplied package.
- Original botanical and architectural reference photographs: missing from accessible workspace and attachments. Photographer, provenance and license unknown. No substitute images are represented as originals; detailed visual comparison remains blocked pending receipt.
- No supplementary historical images are included; therefore no external photograph licenses are asserted.
- Ubuntu and Vazirmatn font files and their respective licenses are included in `assets/fonts`. Ubuntu Regular's fontconfig language coverage does not include Persian; Vazirmatn is a proposed companion, not a silent claim that Ubuntu supports Persian.

## Decisions

Openfund is framed as a proposed parent ecosystem. Branded-house structure, product examples, clear space, minimum size and taglines are recommendations, not existing approved specifications. The legacy trading tagline is reserved as a product-level candidate. Direction A retains recognizable black, lime and off-white; B explores stone and cypress; C explores a broader digital-finance mood. None is represented as a newly approved palette. Logo files are copied unchanged.

## Research

- UNESCO, [Persepolis](https://whc.unesco.org/en/list/114/): the terrace began about 518 BCE under Darius I; architecture, stairways and reliefs.
- A. Shapur Shahbazi, [Persepolis, Encyclopaedia Iranica](https://www.iranicaonline.org/articles/persepolis/): describes cypress trees between delegations on the Apadana stairway.
- Rüdiger Schmitt and David Stronach, [Apadāna, Encyclopaedia Iranica](https://www.iranicaonline.org/articles/apadana/): architectural and relief context.
- [Ubuntu family files and license](https://github.com/google/fonts/tree/main/ufl/ubuntu); [Vazirmatn files and license](https://github.com/google/fonts/tree/main/ofl/vazirmatn).

Historical descriptions and present-day brand interpretations are explicitly separated in both editions. No historical claim is made about the unidentified architectural reference image.

## Outstanding production work

Obtain the two original photographs, provenance and permissions; inspect and annotate the actual images, complete the visual synthesis spreads, and verify any historical identification. Approve strategy, product facts, palette, lockups and typography. Validate final content and accessibility in actual product and print contexts.
